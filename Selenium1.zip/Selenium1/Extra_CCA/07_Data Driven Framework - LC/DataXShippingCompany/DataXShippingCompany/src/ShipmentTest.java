import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ShipmentTest {

	ReadExcel readExcel = new ReadExcel();
	
	@Test(dataProvider = "shipmentValues")
	public void displayShipmentValues(String name, String age, String address, String phoneNumber, String email) {
		readExcel.UpdateArrivalPort();
		String.format(name + "\n" + age + "\n" + address + "\n" + phoneNumber + "\n" + email);
	}

	@DataProvider
	public Object[][] shipmentValues() throws IOException {
		
		XSSFSheet sh = readExcel.readExcel("D:\\Development_Avecto\\Ebox_Workspace\\DataDrivenFramework\\",
				"CustomerDetails.xlsx", "Sheet1");
		Object[][] arrayObject = getExcelData(sh);
		return arrayObject;
	}

	public Object[][] getExcelData(XSSFSheet sh) throws IOException {
		Object[][] arrayExcelData = null;

		int totalNoOfCols = 5;
		int totalNoOfRows = 1;
		System.out.println(totalNoOfCols + "\n" + totalNoOfRows);
		arrayExcelData = new String[totalNoOfRows][totalNoOfCols];
		for (int i = 1; i <= totalNoOfRows; i++) {
			for (int j = 1; j < totalNoOfCols; j++) {
				XSSFCell cell = sh.getRow(i).getCell(j);
				if (cell.getCellType() == XSSFCell.CELL_TYPE_NUMERIC) {
					arrayExcelData[i - 1][j] = cell.getNumericCellValue();
				} else {
					arrayExcelData[i - 1][j] = cell.getStringCellValue();
				}
			}

		}
		return arrayExcelData;
	}

}
