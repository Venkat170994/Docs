import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class WebTest {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();
	public static String url, h2tag, link1, link2, link3, tablecontent1, tablecontent2, result1, result2, result3,
			ShipmentDate, Accountno;

	@Before
	public void setUp() throws Exception {
		driver = new HtmlUnitDriver(true);
		baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/shippingDetails/";
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	}

	@Test
	public void testWeb() throws Exception {
		driver.get(baseUrl + "/index.html");
		// fill your code
		h2tag = driver.findElement(By.tagName("h2")).getText();
		try {
			assertEquals("Shipping Details", h2tag);
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		driver.findElement(By.linkText("6543217")).click();
		try {
			link1 = driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[8]/td[1]")).getText();
			isElementPresent(By.xpath("/html/body/div[2]/table/tbody/tr[8]/td[1]"));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			tablecontent1 = driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[2]/td[1]")).getText();
			assertEquals("Maya", tablecontent1);
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			ShipmentDate = driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[9]/td[1]")).getText();
			assertEquals("03/12/2017", ShipmentDate);
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			Accountno = driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr[10]/td[2]")).getText();
			assertEquals("Account No : 93746537", Accountno);
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@After
	public void tearDown() throws Exception {

		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
