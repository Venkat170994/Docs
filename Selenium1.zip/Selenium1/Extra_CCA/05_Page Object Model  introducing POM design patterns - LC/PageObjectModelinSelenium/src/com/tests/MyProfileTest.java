package com.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pageObjects.LoginPage;
import com.pageObjects.MyProfilePage;

public class MyProfileTest {
 //fill your code
	private WebDriver driver;
	private LoginPage loginPage;
	private MyProfilePage myProfilePage;
	
	@BeforeMethod
	public void launchDriver() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);
	}
	
	@Test
	public void testMyProfile() {
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/Login_Servlet_3883");
		loginPage = new LoginPage(driver);
		myProfilePage = new MyProfilePage(driver);
		loginPage.verifySignIn();
		myProfilePage.verifyMyProfile();
	}
	
	@AfterMethod
	private void quitDriver() {
		driver.quit();
	}
}
