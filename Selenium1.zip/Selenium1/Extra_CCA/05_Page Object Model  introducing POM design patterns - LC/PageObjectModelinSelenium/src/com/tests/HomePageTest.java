package com.tests;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.pageObjects.HomePage;
import com.pageObjects.LoginPage;

public class HomePageTest {

	// fill your code
	private LoginPage loginPage;
	private HomePage homePage;
	private WebDriver driver;

	@BeforeMethod
	public void launchDriver() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(2000, TimeUnit.MILLISECONDS);
	}

	@Test
	public void testHomePage() {
		driver.get("http://apps.qa2qe.cognizant.e-box.co.in/Login_Servlet_3883");
		loginPage = new LoginPage(driver);
		homePage = new HomePage(driver);
		loginPage.verifySignIn();
		homePage.getWelcomeMessage();
	}

	@AfterMethod
	private void quitDriver() {
		driver.quit();
	}
}
