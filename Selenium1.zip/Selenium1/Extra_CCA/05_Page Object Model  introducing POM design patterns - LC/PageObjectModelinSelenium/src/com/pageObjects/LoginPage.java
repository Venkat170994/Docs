package com.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	private WebDriver driver;

	// fill your code
	public LoginPage(WebDriver driver) {
		this.driver = driver;
	}

	public void setUserName(String strUserName) {
		driver.findElement(By.name("username")).sendKeys(strUserName);
	}

	public void setPassword(String strPassword) {
		driver.findElement(By.name("password")).sendKeys(strPassword);
	}

	public void clickLogin() {
		driver.findElement(By.name("login")).click();
	}

	public boolean verifySignIn() {
		setUserName("Admin");
		setPassword("admin123");
		clickLogin();
		return true;

	}
}
