package com.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MyProfilePage {
	private WebDriver driver;
	// fill your code
	public MyProfilePage(WebDriver driver) {
		this.driver = driver;
	}

	public String getName() {
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[1]/td[2]")).getText();
	}

	public String getUsername() {
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[2]/td[2]")).getText();
	}

	public String getEmail() {
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[3]/td[2]")).getText();
	}

	public String getRole() {
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[4]/td[2]")).getText();
	}

	public String getAddress() {
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[5]/td[2]")).getText();
	}

	public String getCity() {
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[6]/td[2]")).getText();
	}

	public String getState() {
		return driver.findElement(By.xpath("/html/body/table/tbody/tr[7]/td[2]")).getText();
	}

	public void clickLogin() {
		driver.findElement(By.id("profile")).click();
	}

	public boolean verifyMyProfile() {
		clickLogin();
		getName();
		getUsername();
		getEmail();
		getRole();
		getAddress();
		getCity();
		getState();
		return true;
	}

}
