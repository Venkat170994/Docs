import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class WebTest {
	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	static String url, nameFailMessage, invoiceFailMessage, amountFailMessage, passMessage;
	static WebElement name, old, new1, number, approved, pending, rejected, amount, comments, category, mobile;

	@Before
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		baseUrl = "http://apps.qa2qe.cognizant.e-box.co.in/InvoiceUpdates/";
		driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
	}

	@Test
	public void testWeb() throws Exception {
		driver.get(baseUrl + "/index.html");
		// fill your code
		try {
			name = driver.findElement(By.id("name"));
			assertTrue(isElementPresent(By.id("name")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			number = driver.findElement(By.id("number"));
			assertTrue(isElementPresent(By.id("number")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			approved = driver
					.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/form/table/tbody/tr[3]/td[2]/input[1]"));
			assertTrue(isElementPresent(
					By.xpath("/html/body/div[2]/div[1]/div[2]/form/table/tbody/tr[3]/td[2]/input[1]")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			pending = driver
					.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/form/table/tbody/tr[3]/td[2]/input[2]"));
			assertTrue(isElementPresent(
					By.xpath("/html/body/div[2]/div[1]/div[2]/form/table/tbody/tr[3]/td[2]/input[2]")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			rejected = driver
					.findElement(By.xpath("/html/body/div[2]/div[1]/div[2]/form/table/tbody/tr[3]/td[2]/input[3]"));
			assertTrue(isElementPresent(
					By.xpath("/html/body/div[2]/div[1]/div[2]/form/table/tbody/tr[3]/td[2]/input[3]")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}

		try {
			amount = driver.findElement(By.name("amount"));
			assertTrue(isElementPresent(By.name("amount")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			assertTrue(isElementPresent(By.name("num")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		try {
			comments = driver.findElement(By.name("comments"));
			assertTrue(isElementPresent(By.name("comments")));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	
		
		number.clear();
		number.sendKeys("IV1123");
		amount.clear();
		amount.sendKeys("652130");
		mobile.clear();
		mobile.sendKeys("9629923945");
		comments.clear();
		comments.sendKeys("No Comments");
		driver.findElement(By.id("submit")).click();
		try {
			assertTrue(driver.findElement(By.id("error1")).getText()
					.matches("^exact:[\\s\\S]*[\\s\\S]*Name can't be blank[\\s\\S]*[\\s\\S]*$"));
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
		name.clear();
		name.sendKeys("John");
		number.clear();
		number.sendKeys("IV1123");
		amount.clear();
		amount.sendKeys("652130");
		mobile.clear();
		mobile.sendKeys("9629923945");
		comments.clear();
		comments.sendKeys("No Comments");
		driver.findElement(By.id("submit")).click();
		try {
			assertEquals("your invoice number",
					driver.findElement(By.xpath("//div[@id='result']/table/tbody/tr/td[3]")).getText());
		} catch (Error e) {
			verificationErrors.append(e.toString());
		}
	}

	@After
	public void tearDown() throws Exception {

		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	private String closeAlertAndGetItsText() {
		try {
			Alert alert = driver.switchTo().alert();
			String alertText = alert.getText();
			if (acceptNextAlert) {
				alert.accept();
			} else {
				alert.dismiss();
			}
			return alertText;
		} finally {
			acceptNextAlert = true;
		}
	}
}
