package com.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CommodityForm {

	private WebDriver driver;

	public CommodityForm(WebDriver driver) {
		this.driver = driver;
	}

	public void setName(String name) {
		driver.findElement(By.name("name")).sendKeys(name);
	}

	public void setWeight(String weight) {
		driver.findElement(By.name("weight")).sendKeys(weight);
	}

	public void setLength(String length) {
		driver.findElement(By.name("length")).sendKeys(length);
	}

	public void setWidth(String width) {
		driver.findElement(By.name("width")).sendKeys(width);
	}

	public void setHeight(String height) {
		driver.findElement(By.name("height")).sendKeys(height);
	}

	public void clickAdd() {
		driver.findElement(By.name("add")).click();
	}

	public String getCount() {
		return driver.findElement(By.name("count")).getAttribute("value");
	}

	public String getTotal() {
		return driver.findElement(By.name("total")).getAttribute("value");
	}
}
