package com.tests;

import org.openqa.selenium.WebDriver;

public class DriverSetup {

	private WebDriver driver;

	public DriverSetup(WebDriver driver) {
		this.driver = driver;

	}
	
}
